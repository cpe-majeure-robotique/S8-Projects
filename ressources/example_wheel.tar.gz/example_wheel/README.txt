COMPILE :

cc -g -O2 -Wall  -funsigned-char ffcfstress.c  -lm -o ffcfstress

EXAMPLE 
CHECK event associate with Wheel

./ffcfstress -d /dev/input/event18
