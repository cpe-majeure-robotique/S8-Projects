/*
 * test.c
 *
 *  Created on: 28 avr. 2021
 *      Author: raph
 */

#include "test.h"

// Private functions
static int test_acc(void);
static int test_can(void);
static int test_fuel(void);
static int test_lights(void);
static int test_powertrain(void);
static int test_switches(void);
static int test_end(void);

// ---------------------------------------------------------------------------------------


int test_board(void)
{
	int r = 0;

	// display
	set_fuel_level(100);
	r += test_lights();
	r += test_powertrain();
	HAL_Delay(2000);
	set_fuel_level(10);

	// com
	r += test_can();

	// Sensors
	r += test_acc();
	r += test_switches();

	test_end();

	return r;
}




// ---------------------------------------------------------------------------------------

static int test_acc(void)
{

	return 0;
}


static int test_can(void)
{

	return 0;
}


static int test_end(void)
{

	set_low_beam(true);
	set_high_beam(true);
	HAL_Delay(500);
	set_low_beam(false);
	set_high_beam(false);

	return 0;
}


static int test_fuel(void)
{
	set_fuel_level(0);
	HAL_Delay(2000);
	set_fuel_level(100);
	HAL_Delay(20000);
	set_fuel_level(0);
	HAL_Delay(2000);

	return 0;
}


static int test_lights(void)
{
	  // Beam
	  set_low_beam(true);
	  HAL_Delay(500);
	  set_low_beam(false);
	  set_high_beam(true);
	  HAL_Delay(500);
	  set_low_beam(false);
	  set_high_beam(false);

	  //Blink
	  set_blink_state(left_blink_on);
	  HAL_Delay(1200);
	  set_blink_state(right_blink_on);
	  HAL_Delay(1200);
	  set_blink_state(blink_off);
	  HAL_Delay(500);



	return 0;
}


static int test_powertrain(void)
{
	  // Gear
	  set_gear(5);
	  HAL_Delay(500);
	  set_gear(4);
	  HAL_Delay(500);
	  set_gear(3);
	  HAL_Delay(500);
	  set_gear(2);
	  HAL_Delay(500);
	  set_gear(1);
	  HAL_Delay(500);
	  set_gear(0);

	  // Speed
	  set_speed(50);
	  HAL_Delay(1000);
	  set_speed(0);

	  // RPM
	  set_rpm(6000);
	  HAL_Delay(1500);
	  set_rpm(0);

	return 0;
}



static int test_switches(void)
{

	return 0;
}
