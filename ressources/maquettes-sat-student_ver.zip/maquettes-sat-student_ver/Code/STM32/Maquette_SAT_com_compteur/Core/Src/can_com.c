/*
 * can_com.c
 *
 *  Created on: Feb 25, 2021
 *      Author: Raphaël LEBER
 */


/* Includes ------------------------------------------------------------------*/
#include "can_com.h"
#include "dashboard.h"

uint32_t              TxMailbox1;
uint32_t              TxMailbox2;
HAL_StatusTypeDef 	  status;

static void lightings(CAN_RxHeaderTypeDef RxHeader, uint8_t *RxData);
static void motor(CAN_RxHeaderTypeDef RxHeader, uint8_t *RxData);
static void speed(CAN_RxHeaderTypeDef RxHeader, uint8_t *RxData);


/*
 * @brief : Init CAN1 and CAN2
 */
void CAN_COM_Init(void)
{
	CAN_FilterTypeDef  sFilterConfig;

	 /*##-2- Configure the CAN Filter ###########################################*/
	  sFilterConfig.FilterBank = 0;
	  sFilterConfig.FilterMode = CAN_FILTERMODE_IDMASK;
	  sFilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;
	  sFilterConfig.FilterIdHigh = 0x0000;
	  sFilterConfig.FilterIdLow = 0x0000;
	  sFilterConfig.FilterMaskIdHigh = 0x0000;
	  sFilterConfig.FilterMaskIdLow = 0x0000;
	  sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO0;
	  sFilterConfig.FilterActivation = ENABLE;
	  sFilterConfig.SlaveStartFilterBank = 14;

	  if (HAL_CAN_ConfigFilter(&hcan1, &sFilterConfig) != HAL_OK)
	  {
	    /* Filter configuration Error */
	    Error_Handler();
	  }

	  sFilterConfig.FilterBank = 18;
	  sFilterConfig.SlaveStartFilterBank = 15;

	  if (HAL_CAN_ConfigFilter(&hcan2, &sFilterConfig) != HAL_OK)
	  {
	    /* Filter configuration Error */
	    Error_Handler();
	  }

	  /*##-3- Start the CAN peripheral ###########################################*/
	  if (HAL_CAN_Start(&hcan1) != HAL_OK)
	  {
	    /* Start Error */
	    Error_Handler();
	  }
	  if (HAL_CAN_Start(&hcan2) != HAL_OK)
	  {
	    /* Start Error */
	    Error_Handler();
	  }

	  /*##-4- Activate CAN RX notification #######################################*/
	  if (HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING) != HAL_OK)
	  {
	    /* Notification Error */
	    Error_Handler();
	  }
	  if (HAL_CAN_ActivateNotification(&hcan2, CAN_IT_RX_FIFO0_MSG_PENDING) != HAL_OK)
	  {
	    /* Notification Error */
	    Error_Handler();
	  }

}


/*
 * @brief : Get CAN frames and dispatch them into matching functions
 * @param[in] *hcan
 * 				CAN handle
 */
void CAN_COM_Map(CAN_HandleTypeDef *hcan)
{
	CAN_RxHeaderTypeDef   RxHeader;
	uint8_t               RxData[8];

	/* Get RX message */
	if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &RxHeader, RxData) != HAL_OK)
	{
		/* Reception Error */
		Error_Handler();
	}

	uint32_t id = 0;
	if(RxHeader.IDE != CAN_ID_STD) {
		id = RxHeader.ExtId;
	} else {
		id = RxHeader.StdId;
	}

	switch(id)
	{
		case e_CAN_SPEED:		speed		(RxHeader, RxData); 		break;

		// TODO : Fill in using e_CAN_SPEED case as an example, and call the static methods below :
	}

}

/*
 * @brief : Send CAN frame on CAN2 with commodo orders for lightings
 */
void CAN_send_lightings(void)
{

	enum Blink_state blink_cmd;
	enum Beam_state beam_cmd;
	CAN_TxHeaderTypeDef   TxHeader;
	uint8_t               TxData[8];

	blink_cmd = get_blink_cmd();
	beam_cmd = get_beam_cmd();


	// TODO : Fill in TxHeader and TxData and send on CAN2 with HAL_CAN_AddTxMessage()

}


//------------------- STATIC FUNCTIONS ----------------------------------------


/*
 * @brief : Set lightings (blink, beam) according to frame data
 * @param[in] RxHeader, *RxData
 * 				CAN Rx Header containing DLC, ID, ...
 * 				CAN Data pointer
 */
static void lightings(CAN_RxHeaderTypeDef RxHeader, uint8_t *RxData)
{

	// TODO : Fill in using speed() as an example, and use the following methods :
	// - set_high_beam()
	// - set_low_beam
	// - set_blink_state()

}


/*
 * @brief : Set motor speed (rpm) according to frame data
 * @param[in] RxHeader, *RxData
 * 				CAN Rx Header containing DLC, ID, ...
 * 				CAN Data pointer
 */
static void motor(CAN_RxHeaderTypeDef RxHeader, uint8_t *RxData)
{
	// TODO : Fill in using speed() as an example, and use the following methods :
	// - set_rpm()
}


/*
 * @brief : Set vehicle speed (km/h) and gear ratio according to frame data
 * @param[in] RxHeader, *RxData
 * 				CAN Rx Header containing DLC, ID, ...
 * 				CAN Data pointer
 */
static void speed(CAN_RxHeaderTypeDef RxHeader, uint8_t *RxData)
{
	if(RxHeader.DLC >= 1)
	{
		set_speed(RxData[0]);
	}

	if(RxHeader.DLC >= 2)
	{
		set_gear(RxData[1]);
	}
}


