/*
 * dashboard.h
 *
 *  Created on: 28 avr. 2021
 *      Author: raph
 */


/* --------------------------------------------------------------------------*/

#ifndef __TEST_H__
#define __TEST_H__

#include "main.h"


/* Function declaration -----------------------------------------------------*/
int test_board(void);


#endif /* __TEST_H__ */
