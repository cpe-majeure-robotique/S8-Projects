/*
 * commodo.h
 *
 *  Created on: 30 avr. 2021
 *      Author: raph
 */

#ifndef INC_COMMODO_H_
#define INC_COMMODO_H_

#define COMMODO_RES	4096
#define COMMODO_REF	(COMMODO_RES - 700)
#define COMMODO_OFFSET 2

#include "adc.h"


void update_commodo_cmd(ADC_HandleTypeDef* hadc);


#endif /* INC_COMMODO_H_ */
