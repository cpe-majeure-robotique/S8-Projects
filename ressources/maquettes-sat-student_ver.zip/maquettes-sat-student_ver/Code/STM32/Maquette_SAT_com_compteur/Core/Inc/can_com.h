/*
 * can_com.h
 *
 *  Created on: Feb 25, 2021
 *      Author: raph
 */

#ifndef INC_CAN_COM_H_
#define INC_CAN_COM_H_

#include "can.h"

enum {
	e_CAN_LIGHTINGS = 	0x123,
	e_CAN_MOTOR =  		0x0000000C06,
	e_CAN_SPEED = 		0x0000000C07
};

void CAN_COM_Init(void);
void CAN_COM_Map(CAN_HandleTypeDef *hcan);
void CAN_send_lightings(void);


#endif /* INC_CAN_COM_H_ */
