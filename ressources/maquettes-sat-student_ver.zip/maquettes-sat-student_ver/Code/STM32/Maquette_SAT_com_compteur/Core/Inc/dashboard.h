/*
 * dashboard.h
 *
 *  Created on: 5 févr. 2021
 *      Author: sebastien.altounian
 */

/* --------------------------------------------------------------------------*/

#ifndef __DASHBOARD_H__
#define __DASHBOARD_H__

#include "main.h"

/* Defines ------------------------------------------------------------------*/

/* ---------- Timers ----------*/
#define TIM_SPEED				TIM2
#define TIM_CCR_SPEED			CCR2
#define TIM_PERIOD_SPEED		1000

#define TIM_RPM					TIM5
#define TIM_CCR_RPM				CCR4
#define TIM_PERIOD_RPM			1000

#define TIM_FUEL_LEVEL			TIM1
#define TIM_CCR_FUEL_LEVEL		CCR1
#define TIM_PERIOD_FUEL_LEVEL	100


/* ---------- GPIO ----------*/
#define GPIO_TLE_CS				GPIOA
#define GPIO_PIN_TLE_CS			GPIO_PIN_4

#define GPIO_TLE_ENABLE			GPIOB
#define GPIO_PIN_TLE_ENABLE		GPIO_PIN_10


/* ---------- TLE Pinout ----------*/
#define LEFT_BLINK_OUT_NB		out10
#define GR4_OUT_NB				out9
#define LOW_BEAM_OUT_NB			out8
#define GR1_OUT_NB				out7
#define GR5_OUT_NB				out6
#define GR3_OUT_NB				out5
#define GR2_OUT_NB				out4
#define HIGH_BEAM_OUT_NB		out3
#define RIGHT_BLINK_OUT_NB		out2
#define N_OUT_NB				out1


/* ---------- TLE SPI Addresses ----------*/
#define HB_ACT_1_CTRL			0x0001
#define HB_ACT_2_CTRL			0x0041
#define HB_ACT_3_CTRL			0x0021

#define TLE_WRITE_MASK			0x0080
#define TLE_LABT_MASK			0x0002

#define TLE_DATA_MASK			0xFF00
#define TLE_ADDRESS_MASK		0x00FF

#define TLE_1ST_OUTPUT_MASK		0xC000
#define TLE_2ND_OUTPUT_MASK		0x3000
#define TLE_3RD_OUTPUT_MASK		0x0C00
#define TLE_4TH_OUTPUT_MASK		0x0300

#define HIGH_BEAM_ON			0x2000
#define HIGH_BEAM_OFF			0x1000
#define LOW_BEAM_ON				0x8000
#define LOW_BEAM_OFF			0x4000


/* enum ---------------------------------------------------------------------*/
enum Blink_state
{
	blink_off,		// = 0
	right_blink_on,	// = 1
	left_blink_on,	// = 2
	warning_on		// = 3
};

enum Beam_state
{
	beam_off,		// = 0
	low_beam_on,	// = 1
	high_beam_on,	// = 2
};

enum Bool
{
	false,
	true
};

enum TLE_outpout
{
	out1,
	out2,
	out3,
	out4,
	out5,
	out6,
	out7,
	out8,
	out9,
	out10
};

enum Gear
{
	N,
	GR1,
	GR2,
	GR3,
	GR4,
	GR5
};

/* Function declaration -----------------------------------------------------*/
int init_dashboard(void);

int set_speed(int speed);
int set_rpm(int rpm);
int set_fuel_level(int fuel_level);

int set_gear(int gear);

int manage_blink(void);
int set_right_blink(enum Bool right_blink_state);
int set_left_blink(enum Bool left_blink_state);

int set_low_beam(enum Bool low_beam_state);
int set_high_beam(enum Bool high_beam_state);

void set_blink_state(enum Blink_state bs);
enum Blink_state get_blink_state(void);
void set_blink_cmd(enum Blink_state bs);
enum Blink_state get_blink_cmd(void);

void set_beam_state(enum Beam_state bs);
enum Beam_state get_beam_state(void);
void set_beam_cmd(enum Beam_state bs);
enum Beam_state get_beam_cmd(void);

#endif /* INC_DASHBOARD_H_ */
