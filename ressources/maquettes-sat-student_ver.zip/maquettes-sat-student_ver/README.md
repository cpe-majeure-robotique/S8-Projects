# Maquettes SAT

La maquette de TP permet d'avoir une partie physique à l'architecture du véhicule qui est principalement virtuelle dans le cadre du TP

La maquette de TP peut se décliner sous 2 formes :
- Un calculateur
- Un dashbord avec commodo

avec des dongles CAN pour les lier en eux.

## Matériel

- Nucléo
- Compteur
- Shield Nucléo :
    - Commodo clignotant
    - Interfaçage compteur :
        - Vitesse (km/h)
        - Boite de vitesse (N,1,2,3,4,5)
        - Feux
        - Clignotants
        - Fuel
    - Bus CAN x2
    - Alimentation  
- Boîtier (impression 3D)



![compteur](img/WUPP-compteur.jpg)





